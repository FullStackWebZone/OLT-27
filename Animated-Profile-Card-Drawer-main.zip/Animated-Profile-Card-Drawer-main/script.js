let card = document.querySelector(".card");
let cardtoggle = document.querySelector(".toggle");
cardtoggle.onclick = function () {
  card.classList.toggle("active");
};