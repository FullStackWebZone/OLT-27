# Animated-Action-Menu-HTML-CSS-JS
Animated Action Menu using Html CSS & Vanilla Javascript



https://user-images.githubusercontent.com/76597088/183308823-c6b21068-af17-4117-8091-eed98de96d5d.mp4

