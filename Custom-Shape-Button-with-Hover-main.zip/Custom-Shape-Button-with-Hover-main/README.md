# Custom Shape Button with Hover Effect

![1_lJ32Bl-lHWmNMUSiSq17gQ](https://user-images.githubusercontent.com/72864817/171863780-16f7afb7-32a5-4547-a427-23c8a8ed0524.png)

# Screenshots

## Before

![image](https://user-images.githubusercontent.com/72864817/176004423-aa6f4ea4-8dc1-462f-9565-d338f7acb9e4.png)

## After

![image](https://user-images.githubusercontent.com/72864817/176004549-47812b84-2156-4ec6-87f9-01cd30452f68.png)
